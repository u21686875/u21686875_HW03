﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using u21686875_HW03.Models;

namespace u21686875_HW03.Controllers
{
    public class AboutController : Controller
    {
        // GET: About
        public ActionResult Index()
        {
            string[] Imagepaths = Directory.GetFiles(Server.MapPath("~/Media/Images/"));

            List<ModelFile> images = new List<ModelFile>();

            foreach (string imagepath in Imagepaths)
            {
                images.Add(new ModelFile { FileName = Path.GetFileName(imagepath) });
            }
            return View(images);
        }
    }
}